enum EstadoAlimento { buenEstado, proximoVencer, vencido }

class Alimento {
  final String id;
  final String nombre;
  final String categoria;
  final int cantidad;
  final DateTime fechaCompra;
  final DateTime fechaVencimiento;

  const Alimento({
    required this.id,
    required this.nombre,
    required this.categoria,
    required this.cantidad,
    required this.fechaCompra,
    required this.fechaVencimiento,
  });

  int get diasRestantes {
    final ahora = DateTime.now();
    final hoy = DateTime(ahora.year, ahora.month, ahora.day);

    final vencimiento = DateTime(
      fechaVencimiento.year,
      fechaVencimiento.month,
      fechaVencimiento.day,
    );

    return vencimiento.difference(hoy).inDays;
  }

  EstadoAlimento get estado {
    if (diasRestantes < 0) {
      return EstadoAlimento.vencido;
    }

    if (diasRestantes <= 3) {
      return EstadoAlimento.proximoVencer;
    }

    return EstadoAlimento.buenEstado;
  }

  Alimento copiarCon({int? cantidad}) {
    return Alimento(
      id: id,
      nombre: nombre,
      categoria: categoria,
      cantidad: cantidad ?? this.cantidad,
      fechaCompra: fechaCompra,
      fechaVencimiento: fechaVencimiento,
    );
  }
}
