import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'firebase_options.dart';
import 'screens/inicio_screen.dart';
import 'services/alimento_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(const NoDesperdiciesApp());
}

class NoDesperdiciesApp extends StatefulWidget {
  const NoDesperdiciesApp({super.key});

  @override
  State<NoDesperdiciesApp> createState() => _NoDesperdiciesAppState();
}

class _NoDesperdiciesAppState extends State<NoDesperdiciesApp> {
  late final AlimentoService _servicio;

  @override
  void initState() {
    super.initState();
    _servicio = AlimentoService();
  }

  @override
  void dispose() {
    _servicio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const verde = Color(0xFF159957);

    return MaterialApp(
      title: 'No Desperdicies',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: verde, primary: verde),
        scaffoldBackgroundColor: const Color(0xFFF8FAF8),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF8FAF8),
          foregroundColor: Color(0xFF18352A),
          elevation: 0,
        ),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
        ),
        cardTheme: const CardThemeData(
          color: Colors.white,
          surfaceTintColor: Colors.transparent,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: verde,
          foregroundColor: Colors.white,
        ),
      ),
      home: InicioScreen(servicio: _servicio),
    );
  }
}
