import 'package:flutter/foundation.dart';

import '../models/alimento.dart';

class AlimentoService extends ChangeNotifier {
  final List<Alimento> _alimentos = [];

  List<Alimento> get alimentos => List.unmodifiable(_alimentos);

  int get total => _alimentos.length;

  int get totalBuenEstado =>
      _alimentos.where((a) => a.estado == EstadoAlimento.buenEstado).length;

  int get totalPorVencer =>
      _alimentos.where((a) => a.estado == EstadoAlimento.proximoVencer).length;

  int get totalVencidos =>
      _alimentos.where((a) => a.estado == EstadoAlimento.vencido).length;

  void agregar(Alimento alimento) {
    _alimentos.add(alimento);
    notifyListeners();
  }

  void eliminar(String id) {
    _alimentos.removeWhere((a) => a.id == id);
    notifyListeners();
  }

  void actualizarCantidad(Alimento alimento, int cantidad) {
    if (cantidad < 1) return;

    final indice = _alimentos.indexWhere((a) => a.id == alimento.id);

    if (indice == -1) return;

    _alimentos[indice] = _alimentos[indice].copiarCon(cantidad: cantidad);

    notifyListeners();
  }
}
